<?php


?>
<!DOCTYPEhtml>
<html>
<head>
<title></title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>

<div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Treasure Hunt</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user_1"></span></a></li>
      <li><a href="#"><span class="glyphicon glyphicon-log-in_1"></span></a></li>
    </ul>
  </div>
</nav>
</div>

<div class="container">
<div class="row">
<div class="col-sm-12" style="text-align: center"><img src="treaassasinhide/myimg.jpg" style="height: 400px; width: 600px"></div>
</div>


</div>
<script type="text/javascript" src="bootstrap/js/bootstrap.js" ></script>

</body>
</html>